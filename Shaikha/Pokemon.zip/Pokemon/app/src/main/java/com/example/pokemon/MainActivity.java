package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Pokemon> pokeball = new ArrayList<>();

        Pokemon P1 = new Pokemon("Bulbasaur",R.drawable.bulbasaur, 49, 49, 318);
        Pokemon P2 = new Pokemon("Ivysaur",R.drawable.ivysaur, 62, 63, 405);
        Pokemon P3 = new Pokemon("Venusaur", R.drawable.venusaur,82, 83, 525);
        Pokemon P4 = new Pokemon("Charmander", R.drawable.charmander,52, 43, 309);
        Pokemon P5 = new Pokemon("Charmeleon", R.drawable.charmeleon,64, 58, 405);

        pokeball.add(P1);
        pokeball.add(P2);
        pokeball.add(P3);
        pokeball.add(P4);
        pokeball.add(P5);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));

        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(lm);

        PokemonAdapter pa = new PokemonAdapter(pokeball,this);
        recyclerView.setAdapter(pa);
    }
}