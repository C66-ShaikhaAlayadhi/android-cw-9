package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Bundle B = getIntent().getExtras();
        Pokemon P = (Pokemon) B.getSerializable("pokemon");

        ImageView img = findViewById(R.id.imageView2);
        TextView name = findViewById(R.id.textView4);
        TextView attack = findViewById(R.id.textView5);
        TextView defence = findViewById(R.id.textView6);

        img.setImageResource(P.getImage());
        name.setText(P.getName());
        attack.setText("Attack:"+P.getAttack());
        defence.setText("Defence:"+P.getDefence());
    }
}